# ✨ Ecommerce VA Portfolio Website

A **premium, modern, client-winning** personal portfolio website for an Ecommerce Virtual Assistant specializing in **Shopify Product Listing**, **Product Sourcing**, and **Order Fulfillment**.

---

## 🎨 Design Theme
- **Light luxury aesthetic** with elegant **gold / champagne accents**
- **Cormorant Garamond** display font (editorial, high-end feel) + **Jost** body font
- Fully **responsive** — mobile, tablet & desktop
- Color palette: Cream `#FDFAF5` · Gold `#C9A84C` · Ink `#1A1A1A`

---

## 📄 Sections Built

| Section | Features |
|---|---|
| **Navigation** | Sticky, transparent → frosted-glass on scroll, mobile hamburger menu |
| **Hero** | Animated gold particle canvas, typed text effect, animated stat counters, dual CTA buttons |
| **About Me** | Profile photo with fallback SVG, 4 trust highlights, floating Shopify badge |
| **Services** | 4 service cards (Listing, Sourcing ⭐, Fulfillment, Admin) with tilt hover effects |
| **Skills & Tools** | Animated skill progress bars + 12-tool icon grid |
| **Why Hire Me** | 6 value reason cards + dark testimonial quote block |
| **Work Process** | 3 tabbed workflows (Listing / Sourcing / Fulfillment), 4 steps each |
| **Contact** | Contact details, 4 social links, inquiry form with validation & success state |
| **Footer** | Brand statement, navigation columns, CTA button |

---

## ⚡ Interactive Features
- **Gold scroll progress bar** at the top of the page
- **Scroll-triggered animations** (AOS) on all sections
- **Animated counters** in Hero stats (5,000+ Products / 2,000+ Orders / 100% Satisfaction)
- **Animated skill bars** triggered when Skills section enters viewport
- **Tabbed process workflow** switcher (3 workflows)
- **Card tilt effect** on service and reason cards
- **Typed text effect** cycling through 5 service specialties
- **Navbar active link** highlighting as you scroll through sections

---

## 🔗 Social / Profile Links Included
| Platform | URL |
|---|---|
| LinkedIn | http://www.linkedin.com/in/nenafemandinva0213 |
| Facebook | https://www.facebook.com/share/18QurvtN57/ |
| Instagram | https://www.instagram.com/nen.nenskie |
| OnlineJobs.ph | https://www.onlinejobs.ph/jobseekers/info/1608107 |

---

## 🖼️ Adding Your Profile Photo

The photo section loads from **`images/profile.jpg`**. To add your photo:

1. Save your professional headshot as **`images/profile.jpg`** (recommended: 600×750px or portrait ratio)
2. Upload it to the project files
3. The website will automatically display it with the gold frame and badge

> **Fallback:** If no photo is found, a beautiful branded gold SVG placeholder is shown automatically.

---

## 🔧 Personalisation Checklist

Replace these placeholders in `index.html`:

- [ ] **`[Your Name]`** → Your full name (appears in navbar logo, hero, about, footer)
- [ ] **`youremail@example.com`** → Your actual email address
- [ ] **`[Client Name]`** → Replace the testimonial client name
- [ ] **`[Country]`** → Client's country in testimonial
- [ ] Upload your photo as `images/profile.jpg`
- [ ] Adjust stats (5,000+ products, 2,000+ orders) if needed

---

## 📁 File Structure

```
index.html              — Main HTML file (all sections)
css/
  └── style.css         — Complete luxury gold stylesheet
js/
  └── main.js           — All interactive functionality
images/
  ├── profile.jpg       — Your profile photo (upload here)
  └── profile-placeholder.svg  — Auto-shown if photo is missing
README.md
```

---

## 🚀 Deployment

To make your portfolio live, go to the **Publish tab** and click publish. Your website will be deployed instantly with a shareable URL.

---

## 🛠️ Technologies Used

| Tool | Purpose |
|---|---|
| HTML5 | Semantic structure |
| CSS3 | Custom luxury styling with CSS variables |
| Vanilla JavaScript | All interactivity |
| [AOS](https://michalsnik.github.io/aos/) | Scroll animations |
| [Font Awesome 6](https://fontawesome.com/) | Icons |
| Google Fonts | Cormorant Garamond + Jost typography |

---

*Made with ♥ in the Philippines — © 2025 [Your Name] | Ecommerce Virtual Assistant*
